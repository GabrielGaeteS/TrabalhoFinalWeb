-- Execute no PostgreSQL conectado como usuário com permissão para criar bancos.
CREATE DATABASE controle_estoque;
