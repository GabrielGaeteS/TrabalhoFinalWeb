package com.estoque.controller;

import com.estoque.model.Produto;
import com.estoque.service.ProdutoService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProdutoController {

    private final ProdutoService produtoService;

    public ProdutoController(ProdutoService produtoService) {
        this.produtoService = produtoService;
    }

    @GetMapping("/")
    public String inicio() {
        return "index";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/produtos")
    public String listar(Model model) {
        model.addAttribute("produtos", produtoService.listarTodos());
        return "produtos";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/produtos/novo")
    public String novo(Model model) {
        model.addAttribute("produto", new Produto());
        return "cadastro";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/produtos/salvar")
    public String salvar(@Valid Produto produto, BindingResult resultado) {
        if (resultado.hasErrors()) {
            return "cadastro";
        }
        produtoService.salvar(produto);
        return "redirect:/produtos";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/produtos/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Produto produto = produtoService.buscarPorId(id);
        if (produto == null) {
            return "redirect:/produtos";
        }
        model.addAttribute("produto", produto);
        return "edicao";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/produtos/atualizar")
    public String atualizar(@Valid Produto produto, BindingResult resultado) {
        if (resultado.hasErrors()) {
            return "edicao";
        }
        produtoService.salvar(produto);
        return "redirect:/produtos";
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/produtos/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        produtoService.excluir(id);
        return "redirect:/produtos";
    }
}
