package com.estoque.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SegurancaConfig {

    @Bean
    public SecurityFilterChain filtroSeguranca(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(autorizacao -> autorizacao
                .requestMatchers("/", "/login", "/css/**", "/erro").permitAll()
                .requestMatchers("/produtos/novo", "/produtos/salvar", "/produtos/editar/**", "/produtos/atualizar", "/produtos/excluir/**").hasRole("ADMIN")
                .requestMatchers("/produtos", "/produtos/**").hasAnyRole("USER", "ADMIN")
                .anyRequest().authenticated()
            )
            .formLogin(formulario -> formulario
                .loginPage("/login")
                .defaultSuccessUrl("/produtos", true)
                .failureUrl("/login?error")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/login?logout")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
                .permitAll()
            );
        return http.build();
    }

    @Bean
    public PasswordEncoder codificadorDeSenhas() {
        return new BCryptPasswordEncoder();
    }

    // Contas de demonstração para apresentação acadêmica. Em produção, usar cadastro persistido e senhas individuais.
    @Bean
    public UserDetailsService usuarios(PasswordEncoder codificador,
            @Value("${app.demo.user-password:1234}") String senhaUsuario,
            @Value("${app.demo.admin-password:1234}") String senhaAdministrador) {
        UserDetails usuario = User.withUsername("usuario")
            .password(codificador.encode(senhaUsuario))
            .roles("USER")
            .build();
        UserDetails administrador = User.withUsername("admin")
            .password(codificador.encode(senhaAdministrador))
            .roles("ADMIN")
            .build();
        return new InMemoryUserDetailsManager(usuario, administrador);
    }
}
