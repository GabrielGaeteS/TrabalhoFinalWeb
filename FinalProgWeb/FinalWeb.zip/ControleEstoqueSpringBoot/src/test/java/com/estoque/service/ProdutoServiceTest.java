package com.estoque.service;

import com.estoque.model.Produto;
import com.estoque.repository.ProdutoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProdutoServiceTest {

    @Mock
    private ProdutoRepository produtoRepository;

    @InjectMocks
    private ProdutoService produtoService;

    @Test
    void deveListarTodosOsProdutos() {
        Produto produto = new Produto();
        produto.setNome("Teclado");
        when(produtoRepository.findAll()).thenReturn(List.of(produto));

        List<Produto> resultado = produtoService.listarTodos();

        assertEquals(1, resultado.size());
        assertEquals("Teclado", resultado.get(0).getNome());
        verify(produtoRepository).findAll();
    }

    @Test
    void deveSalvarProduto() {
        Produto produto = new Produto();
        produto.setNome("Mouse");
        produto.setCategoria("Periféricos");
        produto.setPreco(new BigDecimal("59.90"));
        produto.setQuantidade(10);
        when(produtoRepository.save(produto)).thenReturn(produto);

        produtoService.salvar(produto);

        verify(produtoRepository).save(produto);
    }

    @Test
    void deveBuscarProdutoPorId() {
        Produto produto = new Produto();
        produto.setId(7L);
        when(produtoRepository.findById(7L)).thenReturn(Optional.of(produto));

        Produto resultado = produtoService.buscarPorId(7L);

        assertEquals(7L, resultado.getId());
    }

    @Test
    void deveExcluirProduto() {
        produtoService.excluir(4L);
        verify(produtoRepository).deleteById(4L);
    }
}
